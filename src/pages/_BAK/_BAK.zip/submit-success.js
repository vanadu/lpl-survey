import React from 'react'
// !VA Next.js components
// import { useState, useEffect } from 'react'
import { useRouter} from 'next/router'
import Link from 'next/link';
import { NextSeo } from 'next-seo'

// !VA Survey Components
// import SurveyComponentMaster from '@/components/SurveyComponentMaster'
// import SurveyComponent from '@/components/SurveyComponent'
import SurveyDevMenu from '@/components/SurveyDevMenu'
import SurveySuccess from '@/components/SurveySuccess'


const SuccessPage = () => {
  return (
    <>  
      <section className="section">
        <div className="page section__inner">
          <SurveySuccess />
        </div>
      </section>
    
    </>
  )
}

export default SuccessPage